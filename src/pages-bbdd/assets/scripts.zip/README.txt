Nota: recuerda seleccionar la base de datos adecuada antes de ejecutar los comandos.
      Puedes crear una base de datos con la orden:

            create database <nombre-de-la-base-de-datos>;

      Puedes seleccionar una base de datos existente con:

            use <nombre-de-la-base-de-datos>;


Una vez iniciada la sesión con tu usuario y seleccionada la base de datos correspondiente,
puedes usar este comando para ejecutar los ficheros:

      source <path-al-fichero-a-ejecutar>


Scripts:

[creaTablasBD.sql]
Crea las tablas para la base de datos.

[cargaBD.sql]
Carga las tablas con datos. Estos datos son los mismos usados en el sitio web
para los ejemplos y ejercicios.

[limpiaBD.sql]
Elimina todos los datos de las tablas, sin borrar las tablas.

[eliminaTablasBD.sql]
Elimina las tablas de la base de datos.

[generaBD.js]
Puedes ejecutar este script con Node para generar datos nuevos de forma aleatoria
y cargarlos después en las tablas de la base de datos. En el propio script hay más
instrucciones a seguir.

